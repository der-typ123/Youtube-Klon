import React from 'react';
import { Layout } from './components/Layout';
import { VideoGrid } from './components/VideoGrid';
import { VideoPlayer } from './components/VideoPlayer';
import { useTheme } from './hooks/useTheme';

const mockVideo = {
  id: 1,
  title: "Getting Started with AI Development",
  channel: "TechAI",
  views: "120K",
  timestamp: "2 days ago",
  description: "Learn the fundamentals of AI development in this comprehensive guide. We'll cover:\n\n• Basic concepts of machine learning\n• Popular AI frameworks\n• Real-world applications\n• Best practices for AI development\n\nDon't forget to like and subscribe for more AI content!"
};

export default function App() {
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      <Layout isDarkMode={isDarkMode} onToggleTheme={toggleTheme}>
        <VideoPlayer video={mockVideo} />
        <div className="mt-8">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4 px-4">
            Recommended Videos
          </h2>
          <VideoGrid />
        </div>
      </Layout>
    </div>
  );
}