import React from 'react';
import { ThumbsUp, ThumbsDown, Share2, Flag } from 'lucide-react';

interface VideoPlayerProps {
  video: {
    id: number;
    title: string;
    channel: string;
    views: string;
    timestamp: string;
    description: string;
  };
}

export function VideoPlayer({ video }: VideoPlayerProps) {
  return (
    <div className="max-w-[1280px] mx-auto p-4">
      <div className="aspect-video bg-black rounded-lg overflow-hidden mb-4">
        {/* Video player placeholder */}
        <div className="w-full h-full flex items-center justify-center text-white">
          Video Player
        </div>
      </div>

      <div className="mb-4">
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2">
          {video.title}
        </h1>
        
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700"></div>
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">{video.channel}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">100K subscribers</p>
            </div>
            <button className="px-4 py-2 bg-red-600 text-white rounded-full hover:bg-red-700">
              Subscribe
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
              <ThumbsUp className="w-5 h-5" />
              <span>23K</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
              <ThumbsDown className="w-5 h-5" />
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
              <Share2 className="w-5 h-5" />
              <span>Share</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
              <Flag className="w-5 h-5" />
              <span>Report</span>
            </button>
          </div>
        </div>
      </div>

      <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 mb-4">
        <div className="flex gap-2 text-sm text-gray-600 dark:text-gray-400 mb-2">
          <span>{video.views} views</span>
          <span>•</span>
          <span>{video.timestamp}</span>
        </div>
        <p className="text-gray-900 dark:text-gray-100 whitespace-pre-line">
          {video.description}
        </p>
      </div>
    </div>
  );
}