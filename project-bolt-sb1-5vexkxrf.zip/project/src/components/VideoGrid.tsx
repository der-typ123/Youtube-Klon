import React from 'react';
import { VideoPlayer } from './VideoPlayer';

const MOCK_VIDEOS = [
  {
    id: 1,
    title: "Getting Started with AI Development",
    thumbnail: "https://images.unsplash.com/photo-1677442136019-21780ecad995",
    channel: "TechAI",
    views: "120K",
    timestamp: "2 days ago",
    description: "Learn the fundamentals of AI development in this comprehensive guide. We'll cover machine learning basics, neural networks, and practical applications.\n\nTopics covered:\n- Introduction to AI\n- Machine Learning Fundamentals\n- Neural Networks\n- Practical Applications"
  },
  {
    id: 2,
    title: "Machine Learning Fundamentals",
    thumbnail: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb",
    channel: "CodeMaster",
    views: "89K",
    timestamp: "5 days ago",
    description: "A deep dive into machine learning fundamentals. Perfect for beginners and intermediate developers looking to expand their knowledge."
  },
  {
    id: 3,
    title: "The Future of AI Technology",
    thumbnail: "https://images.unsplash.com/photo-1677442136019-21780ecad995",
    channel: "FutureTech",
    views: "250K",
    timestamp: "1 week ago",
    description: "Explore the cutting-edge developments in AI technology and what the future holds for artificial intelligence."
  }
];

export function VideoGrid() {
  const [selectedVideo, setSelectedVideo] = React.useState<typeof MOCK_VIDEOS[0] | null>(null);

  if (selectedVideo) {
    return <VideoPlayer video={selectedVideo} />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {MOCK_VIDEOS.map((video) => (
          <div 
            key={video.id} 
            className="flex flex-col cursor-pointer"
            onClick={() => setSelectedVideo(video)}
          >
            <div className="relative aspect-video rounded-lg overflow-hidden">
              <img
                src={video.thumbnail}
                alt={video.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="mt-2">
              <h3 className="font-semibold text-gray-900 dark:text-gray-100">
                {video.title}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {video.channel}
              </p>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {video.views} views • {video.timestamp}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}